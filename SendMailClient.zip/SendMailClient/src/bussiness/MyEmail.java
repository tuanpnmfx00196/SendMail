/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bussiness;

import javax.mail.Session;
import entity.MailMessage;
import entity.SMTPServerMail;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author tuanphan
 */
public class MyEmail{
    
    public Session getMailSession(SMTPServerMail smtp, String from, String password){
     Properties p = new Properties();
        p.put("mail.smtp.auth", "true");
        p.put("mail.smtp.starttls.enable", "true");
        p.put("mail.smtp.host", smtp.getServer());
        p.put("mail.smtp.port", smtp.getPort());
        Session s = Session.getDefaultInstance(p, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication(){
                return new PasswordAuthentication(from, password);
            }
        });
        System.out.println(s);
        return s;
    }
    public boolean SendMail(MailMessage mailMessage, Session s){
        try{
            System.out.println(s);
            MimeMessage miMessage = new MimeMessage(s);
            miMessage.setFrom(new InternetAddress(mailMessage.getFrom()));
            miMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(mailMessage.getFrom()));
            miMessage.setSubject(mailMessage.getSubject());
            miMessage.setText(mailMessage.getMessage());
            Transport.send(miMessage);
        }catch(MessagingException e){
            System.out.println(e); 
        }
        return true;
    }
    public void Test(){
        System.out.println("......");
    }
}
